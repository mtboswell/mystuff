#!/bin/sh

cp ../../template/* *
